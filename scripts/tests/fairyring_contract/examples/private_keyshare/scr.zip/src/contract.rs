use cosmwasm_std::{
    entry_point, to_json_binary, AnyMsg, Binary, Coin, CosmosMsg, Deps, DepsMut, Env, MessageInfo, Reply, Response, StdResult, SubMsg
};
use prost::Message;
use crate::error::ContractError;
use crate::msg::{
    ExecuteMsg, InstantiateMsg, QueryMsg, IdentityResponse, PepRequestMsg, AllIdentitiesResponse,
};
use crate::state::{LAST_REPLY_ID, PENDING_REQUESTS, RECORDS, PendingRequest, IdentityRecord};

// Import your generated request type.
use fairblock_proto::fairyring::pep::{ MsgRequestPrivateIdentity, MsgRequestPrivateIdentityResponse};

#[entry_point]
pub fn instantiate(
    deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    _msg: InstantiateMsg,
) -> Result<Response<PepRequestMsg>, ContractError> {
    LAST_REPLY_ID.save(deps.storage, &0)?;
    Ok(Response::<PepRequestMsg>::new())
}

#[entry_point]
pub fn execute(
    deps: DepsMut,
    env: Env,
    info: MessageInfo,
    msg: ExecuteMsg,
) -> Result<Response<PepRequestMsg>, ContractError> {
    match msg {
        ExecuteMsg::RequestIdentity { price } => execute_request_identity(deps, env, info, price),
        ExecuteMsg::StoreEncryptedData { identity, data } => store_encrypted_data(deps, env, info, identity, data),
    }
}

fn execute_request_identity(
    deps: DepsMut,
    env: Env,
    info: MessageInfo,
    price: Coin,
) -> Result<Response<PepRequestMsg>, ContractError> {
    // Increment our reply id counter.
    let mut reply_id = LAST_REPLY_ID.load(deps.storage)?;
    reply_id += 1;
    LAST_REPLY_ID.save(deps.storage, &reply_id)?;

    // Use the contract's own address as the creator.
    let contract_addr = env.contract.address.to_string();
    
    // Save the pending request info for use in the reply.
    let pending = PendingRequest {
        creator: info.sender.to_string().clone(),
        price: price.clone(),
    };
    PENDING_REQUESTS.save(deps.storage, reply_id, &pending)?;

    // Create a unique request id.
    let req_id = format!("req-{}-{}", info.sender.to_string(), reply_id);

    // Build the inner generated message.
    let inner_msg = MsgRequestPrivateIdentity {
        creator: contract_addr.clone(),
        req_id,
    };

    let e = inner_msg.encode_to_vec();
    let d = Binary::new(e);

    let any_msg = AnyMsg {
        type_url: "/fairyring.pep.MsgRequestPrivateIdentity".to_string(),
        value: d,
    };

    // // Wrap it in our custom request message.
    // let pep_request = PepRequestMsg { inner: inner_msg };

    // Dispatch as a submessage.
    let cosmos_msg = CosmosMsg::Any(any_msg.clone());
    let sub_msg = SubMsg::reply_on_success(cosmos_msg, reply_id);

    Ok(Response::<PepRequestMsg>::new()
        .add_submessage(sub_msg)
        .add_attribute("action", "request_identity")
        .add_attribute("pending_reply_id", reply_id.to_string()))
}

fn store_encrypted_data(
    deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    identity: String,
    data: String,
) -> Result<Response<PepRequestMsg>, ContractError> {
    let mut record = RECORDS.load(deps.storage, identity.as_str())?;
    
    record.encrypted_data = data.clone();
    RECORDS.save(deps.storage, identity.as_str(), &record)?;
    Ok(Response::<PepRequestMsg>::new()
        .add_attribute("action", "store_data")
        .add_attribute("identity", identity)
        .add_attribute("data", data))
}


#[entry_point]
pub fn reply(
    deps: DepsMut,
    _env: Env,
    msg: Reply,
) -> Result<Response<PepRequestMsg>, ContractError> {
    let reply_id = msg.id;
    // Retrieve the pending request info.
    let pending = PENDING_REQUESTS.load(deps.storage, reply_id)
        .map_err(|_| ContractError::PendingRequestNotFound { id: reply_id })?;

    let submsg_result = msg
        .result
        .into_result()
        .map_err(|e| ContractError::ReplyError { error: e.to_string() })?;

    // Use CosmWasm 2.0's msg_responses (the field is now named `value`).
    let binary_data = submsg_result
        .msg_responses
        .get(0)
        .map(|resp| resp.value.clone())
        .ok_or(ContractError::ReplyMissingData {})?;

    // Decode the protobuf-encoded response using prost.
    let pep_response = MsgRequestPrivateIdentityResponse::decode(binary_data.as_slice())
        .map_err(|e| ContractError::ReplyError { error: e.to_string() })?;
    let identity = pep_response.identity;

    // Create and store the identity record.
    let record = IdentityRecord {
        identity: identity.clone(),
        creator: pending.creator,
        encrypted_data: "".to_string(), // left blank as specified
        price: pending.price,
    };
    RECORDS.save(deps.storage, identity.as_str(), &record)?;
    PENDING_REQUESTS.remove(deps.storage, reply_id);

    Ok(Response::<PepRequestMsg>::new()
        .add_attribute("action", "store_identity")
        .add_attribute("identity", identity))
}

#[entry_point]
pub fn query(deps: Deps, _env: Env, msg: QueryMsg) -> StdResult<Binary> {
    match msg {
        QueryMsg::GetIdentity { identity } => to_json_binary(&query_identity(deps, identity)?),
        QueryMsg::GetAllIdentity {} => to_json_binary(&query_all_identities(deps)?),
    }
}

fn query_identity(deps: Deps, identity: String) -> StdResult<IdentityResponse> {
    let record = RECORDS.load(deps.storage, identity.as_str())?;
    Ok(IdentityResponse { record })
}

fn query_all_identities(deps: Deps) -> StdResult<AllIdentitiesResponse> {
    let records: Vec<IdentityRecord> = RECORDS
        .range(deps.storage, None, None, cosmwasm_std::Order::Ascending)
        .map(|item| item.map(|(_, record)| record))
        .collect::<StdResult<Vec<_>>>()?;

    Ok(AllIdentitiesResponse { records })
}